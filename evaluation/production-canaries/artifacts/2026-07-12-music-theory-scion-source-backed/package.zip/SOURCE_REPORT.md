# Source Report — Music Theory Fundamentals

## Research Policy
CourseMapper compiles teaching materials from source ledger rows and atom sourceRefs. Missing URLs, DOI values, or licenses are marked for instructor review rather than invented during compilation.

## Source Ledger
- kr15: Peter Vuust, Maria A. G. Witek (2014). Rhythmic complexity and predictive coding: a novel approach to modeling rhythm and meter perception in music. Open-access via — doi:10.3389/fpsyg.2014.01111/pdf
  - provider=openalex; license=CC BY; url=https://www.frontiersin.org/articles/10.3389/fpsyg.2014.01111/pdf; checkedAt=2026-07-12T00:44:57.873Z
  - concepts=Intervals, How to hear them
- kr16: Jesse Berezovsky (2019). The structure of musical harmony as an ordered phase of sound: A statistical mechanics approach to music theory. Open-access via — https://advances.sciencemag.org/content/advances/5/5/eaav8490.full.pdf
  - provider=openalex; license=CC BY-NC; url=https://advances.sciencemag.org/content/advances/5/5/eaav8490.full.pdf; checkedAt=2026-07-12T00:44:57.873Z
  - concepts=Harmony, Basic chord progressions
- kr17: Daniel Müllensiefen, Bruno Gingras, Jason Musil et al. (2014). The Musicality of Non-Musicians: An Index for Assessing Musical Sophistication in the General Population. Open-access via — doi:10.1371/journal.pone.0089642
  - provider=openalex; license=CC BY; url=https://journals.plos.org/plosone/article/file?id=10.1371/journal.pone.0089642&type=printable; checkedAt=2026-07-12T00:44:57.873Z
  - concepts=Musical form, Final analysis project

## SourceRef Coverage
- outcomes: 14/14 with sourceRefs
- activities: 15/15 with sourceRefs
- examples: 7/7 with sourceRefs
- assessments: 7/7 with sourceRefs
- rubricCriteria: 21/21 with sourceRefs
- factualClaims: 14/14 with sourceRefs
