# Source Report — User Experience Design Studio

## Research Policy
CourseMapper compiles teaching materials from source ledger rows and atom sourceRefs. Missing URLs, DOI values, or licenses are marked for instructor review rather than invented during compilation.

## Source Ledger
- ux-curated-user-experience: User experience — https://en.wikipedia.org/wiki/User_experience
  - provider=wikipedia; license=CC BY-SA 4.0; url=https://en.wikipedia.org/wiki/User_experience; checkedAt=2026-07-12T04:40:14.059Z
  - concepts=user experience, usability, user need, usability testing, test plan, findings, accessibility, evaluation, remediation, user-centered design, design process, iteration, prototype review, feedback
- ux-curated-usability-testing: Usability testing — https://en.wikipedia.org/wiki/Usability_testing
  - provider=wikipedia; license=CC BY-SA 4.0; url=https://en.wikipedia.org/wiki/Usability_testing; checkedAt=2026-07-12T04:40:14.059Z
  - concepts=user experience, usability, user need, usability testing, test plan, findings, accessibility, evaluation, remediation, user-centered design, design process, iteration, prototype review, feedback
- ux-curated-web-accessibility: Web accessibility — https://en.wikipedia.org/wiki/Web_accessibility
  - provider=wikipedia; license=CC BY-SA 4.0; url=https://en.wikipedia.org/wiki/Web_accessibility; checkedAt=2026-07-12T04:40:14.059Z
  - concepts=user experience, usability, user need, usability testing, test plan, findings, accessibility, evaluation, remediation, user-centered design, design process, iteration, prototype review, feedback
- ux-curated-user-centered-design: User-centered design — https://en.wikipedia.org/wiki/User-centered_design
  - provider=wikipedia; license=CC BY-SA 4.0; url=https://en.wikipedia.org/wiki/User-centered_design; checkedAt=2026-07-12T04:40:14.059Z
  - concepts=user experience, usability, user need, usability testing, test plan, findings, accessibility, evaluation, remediation, user-centered design, design process, iteration, prototype review, feedback
- ux-curated-software-prototyping: Software prototyping — https://en.wikipedia.org/wiki/Software_prototyping
  - provider=wikipedia; license=CC BY-SA 4.0; url=https://en.wikipedia.org/wiki/Software_prototyping; checkedAt=2026-07-12T04:40:14.059Z
  - concepts=user experience, usability, user need, usability testing, test plan, findings, accessibility, evaluation, remediation, user-centered design, design process, iteration, prototype review, feedback

## SourceRef Coverage
- outcomes: 24/24 with sourceRefs
- activities: 24/24 with sourceRefs
- examples: 12/12 with sourceRefs
- assessments: 12/12 with sourceRefs
- rubricCriteria: 36/36 with sourceRefs
- factualClaims: 24/24 with sourceRefs
