# Source Report — User Experience Design Studio

## Research Policy
CourseMapper compiles teaching materials from source ledger rows and atom sourceRefs. Missing URLs, DOI values, or licenses are marked for instructor review rather than invented during compilation.

## Source Ledger
- kr1: Qian Yang, Aaron Steinfeld, Carolyn Penstein Rosé et al. (2020). Re-examining Whether, Why, and How Human-AI Interaction Is Uniquely Difficult to Design. Open-access via — doi:10.1145/3313831.3376301
  - provider=openalex; license=CC BY; url=https://dl.acm.org/doi/pdf/10.1145/3313831.3376301; checkedAt=2026-07-10T07:07:29.549Z
  - concepts=Human-centered Design, Affinity & Insight
- kr5: Colin M. Gray, Paul Parsons, Austin L. Toombs et al. (2019). Designing an Aesthetic Learner Experience: UX, Instructional Design, and Design Pedagogy. Open-access via — https://scholarworks.iu.edu/journals/index.php/ijdl/article/download/26065/33591
  - provider=openalex; license=CC BY-NC-SA; url=https://scholarworks.iu.edu/journals/index.php/ijdl/article/download/26065/33591; checkedAt=2026-07-10T07:07:29.549Z
  - concepts=Journey & Blueprint
- sf1: Wikipedia contributors. User interface design. https://en.wikipedia.org/wiki/User_interface_design
  - provider=wikipedia; license=CC BY-SA 4.0; url=https://en.wikipedia.org/wiki/User_interface_design; checkedAt=2026-07-10T07:07:29.549Z
  - concepts=Human-centered Design
- sf2: Wikipedia contributors. Design research. https://en.wikipedia.org/wiki/Design_research
  - provider=wikipedia; license=CC BY-SA 4.0; url=https://en.wikipedia.org/wiki/Design_research; checkedAt=2026-07-10T07:07:29.549Z
  - concepts=Research Planning
- sf3: Wikipedia contributors. User-centered design. https://en.wikipedia.org/wiki/User-centered_design
  - provider=wikipedia; license=CC BY-SA 4.0; url=https://en.wikipedia.org/wiki/User-centered_design; checkedAt=2026-07-10T07:07:29.549Z
  - concepts=Task Flows & Interaction Patterns, Human-centered Design

## Source Review Notes
- kr2: Vero Vanden Abeele, Katta Spiel, Lennart E. Nacke et al. (2019). Development and validation of the player experience inventory: A scale to measure player experiences at the level of functional and psychosocial consequences. Open-access via
  - provider=openalex; status=source-provided; license=CC BY; url=https://doi.org/10.1016/j.ijhcs.2019.102370; checkedAt=2026-07-10T07:07:29.549Z; trustedBibliography=false
- kr4: Jung-Joo Lee, Miia Jaatinen, Anna Salmi et al. (2018). Design Choices Framework for Co-creation Projects. Open-access via https://aaltodoc.aalto.fi/handle/123456789/34066 (cc-by)
  - provider=openalex; status=source-provided; license=CC BY; url=https://aaltodoc.aalto.fi/handle/123456789/34066; checkedAt=2026-07-10T07:07:29.549Z; trustedBibliography=false
