# Required Lab Assets

World Literature references course assets that are not bundled as generated Office documents.
Attach or replace these assets before teaching or publishing the lessons that depend on them.

- Specimen or sample kit (physical)
  Provide the rock, mineral, biological, or chemical samples the bench and field activities reference.
- Experiment list and procedure sheets (.docx, .pdf)
  The course references laboratory work — attach the per-lesson experiment procedures students follow (the "(see experiment list)" reference must resolve to this document).
- Lab safety equipment and briefing (physical, .pdf)
  Goggles, gloves, and the safety briefing students complete before the first bench or field session.
- Hand lenses and observation tools (physical)
  Hand lens or loupe, scales, streak plates, or the discipline-specific observation tools the activities assume.
- Field or lab notebook template (.docx, .pdf)
  A structured template for recording observations, measurements, and conclusions.

This marker is included so kits, datasets, templates, and other non-generated materials are visible package dependencies rather than hidden assumptions.