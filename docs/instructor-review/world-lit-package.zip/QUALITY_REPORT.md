# Crucible Deep Quality Report — World Literature

**Overall: 100/100 (A)** · 0 findings (0 P0 · 0 P1 · 0 P2) · 115 files

## Scores

| Dimension | Weight | Score | Grade |
| --- | ---: | ---: | :---: |
| identity | 20 | 100 | A |
| substance | 20 | 100 | A |
| citations | 15 | 100 | A |
| honesty | 15 | 100 | A |
| discipline | 15 | 100 | A |
| consistency | 10 | 100 | A |
| structure | 10 | 100 | A |
| format | 5 | 100 | A |
| texture | 0 | 73 | C |
| **overall** | 110 | **100** | **A** | |

## Findings

### P0 (0)

_None._

### P1 (0)

_None._

### P2 (0)

_None._
